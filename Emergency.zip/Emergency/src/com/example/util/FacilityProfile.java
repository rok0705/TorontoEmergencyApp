package com.example.util;

public class FacilityProfile extends TargetProfile{
	
	public FacilityProfile(){
		super();
	}
	
}
